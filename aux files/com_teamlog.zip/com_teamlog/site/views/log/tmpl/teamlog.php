<?php

// no direct access
defined('_JEXEC') or die('Restricted access'); ?>

<?php foreach ($this->other_logs as $row) : ?>
<div class="user"><?php echo $row['user']->name; ?>
	<span class="delta"> - <?php $delta = DateHelper::getDeltaOrWeekdayText($row['user']->getStateModified(), $this->user->getParam('timezone')); if ($delta) echo $delta; ?></span>
</div>
<h2 class="state"><?php echo $row['user']->getStateDescription(); ?></h2>
<ul class="log">
<?php foreach ($row['logs'] as $log) : ?>
	<li>
		<a href="javascript:void(0)" class="tooltip" title="<?php echo $log->getProjectName().' :: '.$log->getTaskName().' ('.$log->getDurationText().')'; ?>">
			<?php echo $log->description; ?>
		</a>
		<span class="delta"> - <?php echo DateHelper::getDeltaOrWeekdayText($log->date, $this->user->getParam('timezone'));?> </span>
	</li>
<?php endforeach; ?>
</ul>
<?php endforeach; ?>

