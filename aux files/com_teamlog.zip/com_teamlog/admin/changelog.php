<?php
/**
* Teamlog Joomla! Component
*
* @author    yootheme.com
* @copyright Copyright (C) 2008 YOOtheme Ltd. & Co. KG. All rights reserved.
* @license	 GNU/GPL
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

Changelog
------------

0.9.2 BETA
# Fixed MySQL4 compatible install.sql
# Fixed frontend to use the users timezone
# Fixed 20 task limit in frontend
^ Moved additional language packs to separate zip file
+ Added Turkish language file

0.9.1 BETA
# Fixed PHP4 compatibility
+ Added French language file

0.9.0 BETA
- Public beta release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note