<?php

jimport('joomla.application.component.controller');

class TeamlogController extends JController {

	/**
	 * Display the view
	 */
	function display() {

		// set defaults
		JRequest::setVar('layout', 'default');
		JRequest::setVar('view', 'log');

		switch($this->getTask()) {
			case 'updatestate':
				$this->updateState();
				break;
			case 'addlog':
				$this->addLog();
				break;
			case 'removelog':
				$this->removeLog();
				break;
			case 'updatetodos':
				$this->updateTodos();
				break;
			case 'loadtasks':
				JRequest::setVar('layout', 'tasks');
				break;
			case 'loadtodos':
				JRequest::setVar('layout', 'todos');
				break;
			case 'loaddescription':
				JRequest::setVar('layout', 'description');
				break;
			case 'loadteamlog':
				JRequest::setVar('layout', 'teamlog');
				break;
		}

		parent::display();
	}

	/**
	 * Update state
	 */
	function updateState() {

		$user =& YFactory::getUser();
		$date =& YFactory::getDate();
		$post = JRequest::get('post');
		$msg  = 'SUCCESS';

		if ($post['description'] != $user->getStateDescription()) {
			$user->state_description = $post['description'];
			$user->state_modified = $date->toMySQL();
			if  (!$user->save()) {
				$msg = 'FAILED';
			}
		}

		jexit($msg);
	}

	/**
	 * Add log
	 */
	function addLog() {

		// check for request forgeries
		JRequest::checkToken() or jexit('Invalid Token');

		$user    =& YFactory::getUser();
		$post    =  JRequest::get('post');
		$hours   =  JRequest::getInt('hours');
		$minutes =  JRequest::getInt('minutes');
		$msg     = '';

		$log = new Log();
		$log->user_id = $user->id;
		$log->duration = ($hours * 60) + $minutes;

		// validate post data
		$validation = true;
		if (!isset($post['description']) || $post['description'] == ""){
			JError::raiseWarning(0, JText::_('Please enter a valid description'));
			$validation = false;
		}
		if (!isset($post['project_id']) || $post['project_id'] == ""){
			JError::raiseWarning(0, JText::_('Please select a project'));
			$validation = false;
		}
		if (!isset($post['task_id']) || $post['task_id'] == ""){
			JError::raiseWarning(0, JText::_('Please select a task'));
			$validation = false;
		}
		if ($log->duration == 0){
			JError::raiseWarning(0, JText::_('Please set a task duration'));
			$validation = false;
		}

		if ($validation) {
			// bind post data
			if (!$log->bind($post)) {
				JError::raiseWarning(0, 'Post data bind failed!');
				return false;
			}

			// save log
			if (!$log->save()) {
				JError::raiseWarning(0, 'Save failed!');
				return false;
			}

			// reset user state description
			$date = JFactory::getDate();
			$user->state_description = '';
			$user->state_modified = $date->toMySQL();
			if (!$user->save()) {
				JError::raiseWarning(0, 'Save user failed!');
				return false;
			}

			$msg = JText::_('Added log entry successfully.');
		}

		$link = JRoute::_('index.php?option=com_teamlog&view=log', false);
		$this->setRedirect($link, $msg);
	}

	/**
	 * Remove log
	 */
	function removeLog() {

		$log_id = JRequest::getInt('log_id');

		if  (empty($log_id)) {
			JError::raiseWarning(0, 'Log id empty!');
			return false;
		}

		$log = new Log($log_id);

		if (!$log->delete()) {
			JError::raiseWarning(0, $log->getError());
			$link = JRoute::_('index.php?option=com_teamlog&view=log', false);
			$this->setRedirect($link);
		} else {
			$msg  = JText::_('Log entry deleted successfully.');
			$link = JRoute::_('index.php?option=com_teamlog&view=log', false);
			$this->setRedirect($link, $msg);
		}
	}

	/**
	 * Update todos
	 */
	function updateTodos() {

		// check for request forgeries
		JRequest::checkToken() or jexit('Invalid Token');
		
		$ids   =  JRequest::getVar('todo');

		$model = $this->getModel('Log');
		$todos = $model->getUserTodos();
		
		foreach ($todos as $todo) {
			$state = (isset($ids[$todo->id]) && $ids[$todo->id] == TODO_STATE_DONE) ? TODO_STATE_DONE : TODO_STATE_OPEN; 
			if ($todo->state != $state) {
				$todo->setState($state);
				$todo->save();
			}
		}
		
		jexit('SUCCESS');
	}

}