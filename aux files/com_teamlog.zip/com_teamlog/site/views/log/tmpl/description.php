<?php

// no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php if ($this->project && $this->project->description) : ?>
<div class="project-description">
	<h1><?php echo $this->project->name;?></h1>
	<?php echo $this->project->description;?>	
</div>
<?php endif; ?>