<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

// load mootools
JHTML::_('behavior.mootools');

// load classes
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_teamlog'.DS.'classes'.DS.'factory.php');

$user =& YFactory::getUser();

if ($user->guest) {
	JError::raiseWarning(500, JText::_('ALERTNOTAUTH'));
} else {
	// get request vars
	$controller = JRequest::getWord('controller');
	$task       = JRequest::getCmd('task');

	// require helpers
	require_once(JPATH_COMPONENT.DS.'helpers'.DS.'date.php');

	// load controller
	require_once(JPATH_COMPONENT.DS.'controller.php');
	$classname	= 'TeamlogController'.$controller;
	$controller = new $classname();

	// perform the request task
	$controller->execute($task);
	$controller->redirect();
}