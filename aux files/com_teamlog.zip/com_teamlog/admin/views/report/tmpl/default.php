<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm">
	<div id="content-controls">
		<div class="select-project">
			<?php echo $this->lists['select_project']; ?>
		</div>
		<div class="select-user">
			<?php echo $this->lists['select_user']; ?>
		</div>
		<div class="select-date">
			<?php echo $this->lists['select_date']; ?>
			<?php echo JHTML::_('calendar', $this->from_period, 'from_period', 'from-period', JText::_('DATE_FORMAT_MYSQL_WITHOUT_TIME')); ?>
			<?php echo JHTML::_('calendar', $this->until_period, 'until_period', 'until-period', JText::_('DATE_FORMAT_MYSQL_WITHOUT_TIME')); ?>
			<button onclick="this.form.submit();"><?php echo JText::_('Go'); ?></button>
		</div>
	</div>
	<div id="content-area">
		<?php if ($this->contentLayout) require_once(dirname(__FILE__).DS.$this->contentLayout.'.php');	?>
	</div>
	<input type="hidden" name="option" value="<?php echo $this->option; ?>" />
	<input type="hidden" name="controller" value="<?php echo $this->controller; ?>" />
	<input type="hidden" name="task" value="showReport" />
	<?php echo JHTML::_('form.token'); ?>
</form>

<script type="text/javascript">
	window.addEvent('domready', function(){
		$('period').addEvent('change', function(){
			var from  = $('from-period');
			var until = $('until-period');
			switch (this.value) {
				<?php
					foreach ($this->date_presets as $name => $value) {
						$case  = "case '".$name."':\n";
						$case .= "from.setProperty('value', '".$value['from']."');\n";
						$case .= "until.setProperty('value', '".$value['until']."');\n";
						$case .= "break;\n";
						echo $case;
					}
				?>
			}
			document.adminForm.submit();
		});
	});
</script>
