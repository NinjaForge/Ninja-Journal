<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.model');

/*
   Class: ReportModelReport
   The Model Class for Report
*/
class ReportModelReport extends JModel {

	/**
	 * Method to get project report data
	 *
	 * @access public
	 * @return array
	 */
	function getProjectReport($project_id, $user_id, $from, $until) {
		
		// init vars
		$db              =& JFactory::getDBO();
		$report['data']  = array();
		$report['type']  = array();
		$report['user']  = array();
		$report['total'] = 0;
		
		// create report
		$query = "SELECT a.id AS id, a.description AS log, a.duration AS duration, a.date AS date, b.id AS task_id, b.name AS task_name, c.id AS type_id, c.name AS type_name, d.id AS user_id, d.name AS username"
			. " FROM #__teamlog_log AS a "
			. " LEFT JOIN #__teamlog_task AS b ON a.task_id = b.id"
			. " LEFT JOIN #__teamlog_type AS c ON b.type_id = c.id"
			. " LEFT JOIN #__users AS d ON a.user_id = d.id"
			. " WHERE a.project_id = $project_id"
			. ($user_id ? " AND a.user_id = $user_id" : null)
			. " AND a.date >= '$from 00:00:00' AND a.date <= '$until 23:59:59'"
			. " ORDER BY b.type_id, a.task_id, a.date";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		foreach ($result as $row) {
			if (!isset($report['type'][$row->type_id])) {
				$report['type'][$row->type_id] = array(
					'id' => $row->user_id,
					'name' => $row->type_name,
					'total' => $row->duration);
			} else {
				$report['type'][$row->type_id]['total'] += $row->duration;
			}

			if (!isset($report['type'][$row->type_id]['task'][$row->task_id])) {
				$report['type'][$row->type_id]['task'][$row->task_id] = array(
					'id' => $row->task_id,
					'name' => $row->task_name,
					'log' => array($row->id));
			} else {
				$report['type'][$row->type_id]['task'][$row->task_id]['log'][] = $row->id;
			}

			if (!isset($report['user'][$row->user_id])) {
				$report['user'][$row->user_id] = array(
					'id' => $row->user_id,
					'name' => $row->username,
					'total' => $row->duration);
			} else {
				$report['user'][$row->user_id]['total'] += $row->duration;
			}

			$report['data'][$row->id] = array(
				'id' => $row->id,
				'log' => $row->log,
				'username' => $row->username,
				'date' => $row->date,
				'duration' => $row->duration);
			
			$report['total'] += $row->duration;
		}

		// sort type & user data
		$compare = create_function('$a,$b', 'return $a["total"] == $b["total"] ? 0 : $a["total"] > $b["total"] ? -1 : 1;');
		usort($report['type'], $compare);
		usort($report['user'], $compare);

		return $report;
	}

	/**
	 * Method to get user report data
	 *
	 * @access public
	 * @return array
	 */
	function getUserReport($user_id, $from, $until) {
		
		// init vars
		$db                =& JFactory::getDBO();
		$config            =& JFactory::getConfig();		
		$tzoffset          = $config->getValue('config.offset');
		$report['data']    = array();
		$report['project'] = array();
		$report['total']   = 0;
		
		// create report
		$query = "SELECT a.id AS id, a.description AS log, a.duration AS duration, a.date AS date, b.id AS task_id, b.name AS task_name, c.id AS type_id, c.name AS type_name, d.id AS project_id, d.name AS project_name"
			. " FROM #__teamlog_log AS a "
			. " LEFT JOIN #__teamlog_task AS b ON a.task_id = b.id"
			. " LEFT JOIN #__teamlog_type AS c ON b.type_id = c.id"
			. " LEFT JOIN #__teamlog_project AS d ON a.project_id = d.id"		
			. " WHERE a.user_id = $user_id"
			. " AND a.date >= '$from 00:00:00' AND a.date <= '$until 23:59:59'"
			. " ORDER BY a.date";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		foreach ($result as $row) {
			
			$date  = JFactory::getDate($row->date, $tzoffset);
			$week  = date('Y-W', $date->toUnix());

			if (!isset($report['project'][$row->project_id])) {
				$report['project'][$row->project_id] = array(
					'id' => $row->project_id,
					'name' => $row->project_name,
					'total' => $row->duration);
			} else {
				$report['project'][$row->project_id]['total'] += $row->duration;
			}

			if (!isset($report['data'][$week]['total'])) {
				$report['data'][$week]['title'] = date('F Y', $date->toUnix()).' - '.JText::_('Week').' '.date('W', $date->toUnix());
				$report['data'][$week]['total'] = $row->duration;
			} else {
				$report['data'][$week]['total'] += $row->duration;
			}

			$report['data'][$week]['logs'][] = array(
				'id' => $row->id,
				'project_name' => $row->project_name,
				'type_name' => $row->type_name,
				'task_name' => $row->task_name,
				'log' => $row->log,
				'date' => $row->date,
				'duration' => $row->duration);
			
			$report['total'] += $row->duration;
		}

		// sort project data
		$compare = create_function('$a,$b', 'return $a["total"] == $b["total"] ? 0 : $a["total"] > $b["total"] ? -1 : 1;');
		usort($report['project'], $compare);

		return $report;
	}

	/**
	 * Method to get period report data
	 *
	 * @access public
	 * @return array
	 */
	function getPeriodReport($from, $until) {
		
		// init vars
		$db              =& JFactory::getDBO();
		$report['data']  = array();
		$report['total'] = 0;
		
		// create report
		$query = "SELECT b.id AS id, b.name AS name, SUM(a.duration) AS duration"
			. " FROM #__teamlog_log AS a "
			. " LEFT JOIN #__teamlog_project AS b ON a.project_id = b.id"
			. " WHERE a.date >= '$from 00:00:00' AND a.date <= '$until 23:59:59'"
			. " GROUP BY id"
			. " ORDER BY duration DESC";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		$report['total'] = 0;
		foreach ($result as $row) {
			$report['data'][] = array(
				'id' => $row->id,
				'name' => $row->name,
				'duration' => $row->duration);
			$report['total'] += $row->duration;
		}

		return $report;
	}

}