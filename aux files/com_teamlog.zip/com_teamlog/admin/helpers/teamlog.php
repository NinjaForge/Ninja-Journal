<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

class JHTMLTeamlog {

 	/*
    	Function: projectList
    		Returns project select list html string.
 	*/
	function projectList($options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {
		$query = 'SELECT a.id AS value, a.name AS text'
			. ' FROM #__teamlog_project AS a'
			. ' ORDER BY a.name';
		return JHTMLTeamlog::queryList($query, $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: taskList
    		Returns task select list html string.
 	*/
	function taskList($project_id, $options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {

		if (is_array($options)) {
			reset($options);
		} else {
			$options = array($options);
		}

		$project = new Project($project_id);	
		if ($project) {
			foreach ($project->getTaskTypeArray() as $typename => $tasks){
				if (count($tasks)) {
					$options[] = JHTML::_('select.option', '', $typename);
					foreach ($tasks as $task) {
						$options[] = JHTML::_('select.option', $task->id, '- '.$task->name);
					}
				}
			}
		}
		
		return JHTML::_('select.genericlist', $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: typeList
    		Returns type select list html string.
 	*/
	function typeList($options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {
		$query = 'SELECT a.id AS value, a.name AS text'
			. ' FROM #__teamlog_type AS a'
			. ' ORDER BY a.name';
		return JHTMLTeamlog::queryList($query, $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: userList
    		Returns user select list html string.
 	*/
	function userList($options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {
		$query = 'SELECT a.id AS value, a.name AS text'
			. ' FROM #__users AS a'
			. ' ORDER BY name';
		return JHTMLTeamlog::queryList($query, $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: projectStateList
    		Returns project state select list html string.
 	*/
	function projectStateList($options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {
		return JHTMLTeamlog::arrayList(Project::getStates(), $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: taskStateList
    		Returns task state select list html string.
 	*/
	function taskStateList($options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {
		return JHTMLTeamlog::arrayList(Task::getStates(), $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: todoStateList
    		Returns todo state select list html string.
 	*/
	function todoStateList($options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {
		return JHTMLTeamlog::arrayList(Todo::getStates(), $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}

 	/*
    	Function: queryList
			Returns select list html string.
 	*/
	function queryList($query, $options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {

		if (is_array($options)) {
			reset($options);
		} else {
			$options = array($options);
		}

		$db =& JFactory::getDBO();
		$db->setQuery($query);
		$list = $db->loadObjectList();
		
		if ($db->getErrorMsg()) {
			echo $db->stderr(true);
		} 
		
		$options = array_merge($options, $list);
		return JHTML::_('select.genericlist', $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}	

 	/*
    	Function: arrayList
			Returns select list html string.
 	*/
	function arrayList($array, $options, $name, $attribs = null, $key = 'value', $text = 'text', $selected = null, $idtag = false, $translate = false) {

		if (is_array($options)) {
			reset($options);
		} else {
			$options = array($options);
		}

		$options = array_merge($options, JHTMLTeamlog::listOptions($array));
		return JHTML::_('select.genericlist', $options, $name, $attribs, $key, $text, $selected, $idtag, $translate);		
	}	

 	/*
    	Function: selectOptions
    		Returns select option as JHTML compatible array.
 	*/
	function listOptions($array, $value = 'value', $text = 'text') {
		
		$options = array();
		
		if (is_array($array)) {
			foreach ($array as $val => $txt) {
				$options[] = JHTML::_('select.option', strval($val), $txt, $value, $text);
			}
		}

		return $options;
	}

}