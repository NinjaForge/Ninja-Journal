<?php defined('_JEXEC') or die('Restricted access');

JHTML::script('FusionCharts.js', 'administrator/components/com_teamlog/libraries/fusioncharts/charts/');

$format = JText::_('DATE_FORMAT_LC1');
?>

<div class="report-header">
  <h2><?php $text = ($this->from_period && $this->until_period)?JHTML::_('date', $this->from_period, $format) . ' - ' . JHTML::_('date', $this->until_period, $format):JText::_('No Period Specified');
  echo $text; ?>
  </h2>
</div>
<?php if(count($this->report['data'])){?>

<div class="project-report-charts" style="overflow:hidden;">
	<div style="width:50%; float:left;">
		<?php $this->type_chart->renderChart(); ?>
	</div>
	<div style="width:50%; float:left;">
		<?php $this->user_chart->renderChart(); ?>
	</div>
</div>

<div class="project-report-stats">
	<table class="adminlist">
	<thead>
		<tr>
			<th>
				<?php echo JText::_('Type'); ?>
			</th>
			<th>
				<?php echo JText::_('Task'); ?>
			</th>
			<th>
				<?php echo JText::_('Log'); ?>
			</th>
			<th>
				<?php echo JText::_('User'); ?>
			</th>
			<th>
				<?php echo JText::_('Date'); ?>
			</th>
			<th style="width:100px;">
				<?php echo JText::_('Duration'); ?>
			</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$k = 0;
			foreach ($this->report['type'] as $type) {
				$show_type = true;
				foreach ($type['task'] as $task) {
					$show_task = true;
					foreach ($task['log'] as $log_id) {
						$log = $this->report['data'][$log_id];
						?>
						<tr class="<?php echo "row$k"; ?>">
							<td>
								<?php
									echo ($show_type ? $type['name'] : null);
									$show_type = false;
								?>
							</td>
							<td>
								<?php
									echo ($show_task ? $task['name'] : null);
									$show_task = false;
								?>
							</td>
							<td>
								<?php echo $log['log']; ?>
							</td>
							<td>
								<?php echo $log['username']; ?>
							</td>
							<td>
								<?php echo JHTML::_('date', $log['date'], $format); ?>
							</td>
							<td align="right">
								<?php echo DateHelper::formatTimespan($log['duration'], 'h:m'); ?>
							</td>
						</tr>
						<?php
						$k = 1 - $k;
					}	
				}	
			}
		?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="6" style="font-weight:bold;text-align:right;">
				<?php echo DateHelper::formatTimespan($this->report['total'], 'hr mi'); ?>
			</td>
		</tr>			
	</tfoot>
	</table>
</div>

<?php } else {
	echo JText::_('No Entries Found');
}?>