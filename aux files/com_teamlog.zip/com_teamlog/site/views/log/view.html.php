<?php

jimport( 'joomla.application.component.view');

class TeamlogViewLog extends JView {

	function display($tpl = null) {
		global $mainframe;

		$db   =& YFactory::getDBO();
		$user =& YFactory::getUser();

		// get request vars
		$option     = JRequest::getCmd('option');
		$controller = JRequest::getWord('controller');

		// get data from the model
		$user_logs  =& $this->get('userlogs');
		$other_logs =& $this->get('otherlogs');
		$projects   =& $this->get('projects');
		$todos		=& $this->get('usertodos');

		// set template vars
		$this->assignRef('user_logs', $user_logs);
		$this->assignRef('other_logs', $other_logs);
		$this->assignRef('todos', $todos);
		$this->assignRef('projects', $projects);
		$this->assignRef('user', $user);
		$this->assignRef('option', $option);
		$this->assignRef('controller', $controller);

		parent::display($tpl);
	}

}