<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.controller' );

/*
   Class: ReportController
   The controller class for Report
*/
class ReportController extends JController {

 	/*
	   Function: Constructor

	   Parameters:

	      $default -

	   Returns:

	      See Also:

	*/
	function __construct($default = array()) {
		parent::__construct($default);
	}

	function display() {

		// set the default view
		$view = JRequest::getCmd('view');
		if (empty($view)) {
			JRequest::setVar('view', 'report');
		}

		parent::display();
	}
}