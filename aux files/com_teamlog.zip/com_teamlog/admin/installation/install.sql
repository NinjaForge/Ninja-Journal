/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------

--
-- Table structure for table `jos_teamlog_log`
--

CREATE TABLE `#__teamlog_log` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `duration` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_teamlog_project`
--

CREATE TABLE `#__teamlog_project` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_teamlog_task`
--

CREATE TABLE `#__teamlog_task` (
  `id` int(11) NOT NULL auto_increment,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `type_id` (`type_id`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_teamlog_todo`
--

CREATE TABLE `#__teamlog_todo` (
  `user_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  `id` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_teamlog_type`
--

CREATE TABLE `#__teamlog_type` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_teamlog_userdata`
--

CREATE TABLE `#__teamlog_userdata` (
  `user_id` int(11) NOT NULL,
  `state_description` varchar(255) NOT NULL,
  `state_modified` datetime NOT NULL,
  PRIMARY KEY  (`user_id`)
) TYPE=MyISAM;
