<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

// include assets css/js
$templatepre = strtolower(substr($mainframe->getTemplate(), 0, 3));
JHTML::stylesheet('default.css', 'components/com_teamlog/assets/css/');
if ($templatepre != 'yoo') JHTML::stylesheet('reset.css', 'components/com_teamlog/assets/css/');
JHTML::script('log.js', 'components/com_teamlog/assets/js/');

?>

<div id="yoo-teamlog">

	<h1 class="user">
		<?php echo $this->user->name; ?>
		<a id="todos-trigger" class="todos-trigger" href="javascript:void(0)">[<?php echo count($this->todos); ?> Todos]</a>
	</h1>

	<div class="todos">
		<div class="todos-bg">
			<div class="todos-t">
				<div class="todos-b">
					<div class="todos-l">
						<div id="todos" class="todos-line">
							<?php include('todos.php'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- todos end -->

	<div class="logs">

		<div class="left">

			<div class="log-panel">

				<form method="post" action="<?php echo JRoute::_('index.php');?>">
					<div class="state">
						<?php $text = ($this->user->getStateDescription()) ? $this->user->getStateDescription() : JText::_('DEFAULT_LOG'); ?>
						<textarea id="state" cols="30" rows="5" name="description"><?php echo $text; ?></textarea>
						<span class="delta"><?php $delta = DateHelper::getDeltaOrWeekdayText($this->user->getStateModified(), $this->user->getParam('timezone')); if ($delta) echo $delta; ?></span>
					</div>
					<div>
						<select id="project-id" class="project" name="project_id">
							<option class="option1" value ="">-- <?php echo JText::_('Project');?> --</option>
							<?php foreach ($this->projects as $project) : ?>
								<option value ="<?php echo $project->id; ?>"><?php echo $project->name; ?></option>
							<?php endforeach; ?>
						</select>
						<span id="task-id">
							<select class="task" name="task_id">
								<option class="option1" value ="">-- <?php echo JText::_('Task');?> --</option>
							</select>
						</span>
					</div>
					<div>
						<label for="hours"><?php echo JText::_('Hours');?></label>
						<select class="hours" name="hours" id="hours">
							<?php for ($i=0; $i <= 12; $i++) : ?>
								<option value ="<?php echo $i; ?>"><?php echo $i; ?></option>
							<?php endfor; ?>
						</select>
						<label for="minutes"><?php echo JText::_('Minutes');?></label>
						<select class="minutes" name="minutes" id="minutes">
							<?php for ($i=0; $i < 60; $i+=5) : ?>
								<option value ="<?php echo $i; ?>"><?php echo $i; ?></option>
							<?php endfor; ?>
						</select>
						<button type="submit"><?php echo JText::_('Add to log'); ?></button>
					</div>
					<input type="hidden" value="com_teamlog" name="option"/>
					<input type="hidden" value="addlog" name="task"/>
					<?php echo JHTML::_('form.token'); ?>
				</form>

				<div id="project-description"></div>

			</div>
			<!-- log-panel end -->

			<div class="user-log">

				<?php foreach ($this->user_logs as $date => $logs) : ?>
					<span class="date">
						<?php echo $date; ?>
					</span>
					<ul class="log">
					<?php foreach ($logs as $log) : ?>
						<li>
							<a href="javascript:void(0)" class="tooltip" title="<?php echo $log->getProjectName().' :: '.$log->getTaskName().' ('.$log->getDurationText().')'; ?>"><?php echo $log->description; ?></a>
							<?php
							if(DateHelper::isToday($log->date)){
								?>
								 <span class="delta">
									- <?php	echo JText::sprintf('%S ago', $log->getDeltaText()); ?>
									<a href="<?php echo JRoute::_('index.php?log_id='.$log->id.'&task=removelog');?>"><?php echo JText::_('Delete'); ?></a>
								</span>
								<?php
							}
							?>

						</li>
					<?php endforeach; ?>
					</ul>
				<?php endforeach; ?>
			</div>
			<!-- user-log end -->

		</div>
		<!-- left-log end -->

		<div class="right">

			<?php if (count($this->other_logs)) : ?>
				<div class="team-log">
					<div class="team-log-t">
						<div class="team-log-b">
							<div class="team-log-l">
								<div class="team-log-r">
									<div class="team-log-tl">
										<div class="team-log-tr">
											<div class="team-log-bl">
												<div class="team-log-br">
													<div class="team-log-loading">
														<div class="team-log-line">
															<div id="team-log" class="team-log-hole">
																<?php include('teamlog.php'); ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- team-log end -->

		</div>
		<!-- right-log end -->

	</div>
	<!-- log-container end -->

</div>
<script type="text/javascript">
	window.addEvent('domready', function(){
		var app = new Teamlog('<?php echo JRoute::_('index.php?option='.$this->option.'&controller='.$this->controller.'&view=log&format=raw', false);?>', { msgDeletelog: '<?php echo JText::_('Are you sure you want to delete the log?'); ?>' });
		app.attachEvents();
	});
</script>