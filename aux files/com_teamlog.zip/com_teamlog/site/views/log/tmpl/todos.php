<?php

// no direct access
defined('_JEXEC') or die('Restricted access'); ?>

<?php if ($this->todos) : ?>
<form id="todos-form" method="post" action="<?php echo JRoute::_('index.php');?>">
	<ul>
	<?php
	foreach ($this->todos as $row) :
		?>
		<li <?php echo (($row->state) ? ' class="checked"' : ''); ?>>
			<span></span><?php echo $row->description; ?>
			<input id="todo-<?php echo $row->id; ?>" type="hidden" name="todo[<?php echo $row->id; ?>]" value="<?php echo (($row->state) ? 1 : 0); ?>"/>
		</li>
	<?php endforeach; ?>
	</ul>
	<input type="hidden" value="com_teamlog" name="option"/>
	<input type="hidden" value="log" name="view"/>
	<input type="hidden" value="updatetodos" name="task"/>
	<input type="hidden" value="raw" name="format"/>
	<?php echo JHTML::_('form.token'); ?>
</form>
<?php else : echo JText::_('No Tasks assigned'); ?>
<?php endif; ?>