<?php

jimport( 'joomla.application.component.view');

class TeamlogViewLog extends JView {

	function display($tpl = null) {
		global $mainframe;

		$db   =& YFactory::getDBO();
		$user =& YFactory::getUser();

		// get request vars
		$option     = JRequest::getCmd('option');
		$controller = JRequest::getWord('controller');
		$task       = JRequest::getWord('task');

		switch ($task) {
			case 'loadtasks':
				$task_type_array =& $this->get('tasktypearray');
				$this->assignRef('task_type_array', $task_type_array);
				break;

			case 'loadtodos':
				$todos =& $this->get('usertodos');
				$this->assignRef('todos', $todos);
				break;

			case 'loaddescription':
				$project =& $this->get('project');
				$this->assignRef('project', $project);
				break;

			case 'loadteamlog':
				$other_logs =& $this->get('otherlogs');
				$this->assignRef('other_logs', $other_logs);
				break;
		}

		// set template vars
		$this->assignRef('user', $user);
		$this->assignRef('option', $option);
		$this->assignRef('controller', $controller);

		parent::display($tpl);
	}
}