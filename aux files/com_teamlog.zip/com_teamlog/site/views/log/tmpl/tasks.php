<?php

// no direct access
defined('_JEXEC') or die('Restricted access'); ?>

<select class="task" name="task_id">
	<option class="option1" value ="">-- <?php echo JText::_('Task');?> --</option>
	<?php foreach ($this->task_type_array as $typename => $tasks) : ?>
		<option class="option2" value =""><?php echo $typename; ?></option>
		<?php foreach ($tasks as $task) :?>
			<option value ="<?php echo $task->id; ?>">- <?php echo $task->name; ?></option>
		<?php endforeach; ?>
	<?php endforeach; ?>
</select>