<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
   Class: TableLog
   The Table Class for Log. Manages the database operations.
*/
class TableLog extends JTable {

	// int primary key
	var $id					= null;
	// int
	var $user_id			= null;
	// int
	var $project_id			= null;
	// int
	var $task_id			= null;
	// string
	var $description		= null;
	// int
	var $duration			= null;
	// datetime
	var $date				= null;
	// datetime
	var $created			= null;
	// datetime
	var $modified			= null;

	function __construct(&$db) {
		parent::__construct('#__teamlog_log', 'id', $db);
	}

	function loadObjects($result) {
		$objects = array();
		foreach ($result as $row) {
			$object =& new Log();
			$object->bind($row);
			$objects[] = $object;
		}

		return $objects;
	}

	function getUserLogs($user_id, $limit = 0) {
		$query = " SELECT * "
			. " FROM " . $this->_tbl
			. " WHERE user_id=" . $user_id
			. " ORDER BY date DESC"
			. ($limit ? " LIMIT 0," . $limit : "");
		$this->_db->setQuery($query);

		$result = $this->_db->loadAssocList();
		$return = $this->loadObjects($result);
		return $return;
	}

	function getUserWeekLogs($user_id) {
		$date  = JFactory::getDate();
		$date  = $date->toUnix();
		$date  = mktime(0, 0, 0, date('n', $date), date('j', $date)-7, date('Y', $date));
		$query = " SELECT * "
			. " FROM " . $this->_tbl
			. " WHERE user_id=" . $user_id
			. " AND date > '" . date('Y-m-d H:i:s', $date) . "'"
			. " ORDER BY date DESC";
		$this->_db->setQuery($query);

		$result = $this->_db->loadAssocList();
		$return = $this->loadObjects($result);
		return $return;
	}

	function getProjectLogs($project_id){
		$query = " SELECT * "
			. " FROM " . $this->_tbl
			. " WHERE project_id=" . $project_id
			. " ORDER BY task_id DESC";
		$this->_db->setQuery($query);

		$result = $this->_db->loadAssocList();
		$return = $this->loadObjects($result);
		return $return;
	}

}