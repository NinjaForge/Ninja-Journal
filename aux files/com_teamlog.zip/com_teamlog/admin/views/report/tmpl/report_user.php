<?php defined('_JEXEC') or die('Restricted access');

JHTML::script('FusionCharts.js', 'administrator/components/com_teamlog/libraries/fusioncharts/charts/');

$format = JText::_('DATE_FORMAT_LC1');
?>

<div class="report-header">
  <h2><?php $text = ($this->from_period && $this->until_period)?JHTML::_('date', $this->from_period, $format) . ' - ' . JHTML::_('date', $this->until_period, $format):JText::_('No Period Specified');
  echo $text; ?>
  </h2>
</div>

<?php if (count($this->report['data'])) : ?>

<div class="project-report-charts" style="overflow:hidden;">
	<div style="width:100%; float:left;">
		<?php $this->proj_chart->renderChart(); ?>
	</div>
</div>

<div class="user-report-stats">
	<?php foreach ($this->report['data'] as $week_logs) : ?>
		<div class="user-report-week">
			<h3><?php echo $week_logs['title']; ?></h3>
			<table class="adminlist">
				<thead>
					<tr>
						<th>
							<?php echo JText::_('Project'); ?>
						</th>
						<th>
							<?php echo JText::_('Task'); ?>
						</th>
						<th>
							<?php echo JText::_('Log'); ?>
						</th>
						<th>
							<?php echo JText::_('Date'); ?>
						</th>
						<th style="width:100px;">
							<?php echo JText::_('Duration'); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php $k = 0; foreach ($week_logs['logs'] as $log) : ?>
						<tr class="<?php echo "row$k"; ?>">
							<td>
								<?php echo $log['project_name']; ?>
							</td>
							<td>
								<?php echo $log['task_name']; ?>
							</td>
							<td>
								<?php echo $log['log']; ?>
							</td>
							<td>
								<?php echo JHTML::_('date', $log['date'], $format); ?>
							</td>
							<td align="right">
								<?php echo DateHelper::formatTimespan($log['duration'], 'h:m'); ?>
							</td>
						</tr>
					<?php $k = 1 - $k; endforeach; ?>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="5" style="font-weight:bold;text-align:right;">
							<?php echo DateHelper::formatTimespan($week_logs['total'], 'hr mi'); ?>
						</td>
					</tr>
				</tfoot>
			</table>
		</div>
	<?php endforeach; ?>
</div>

<?php else : ?>
	<?php echo JText::_('No Entries Found'); ?>
<?php endif; ?>