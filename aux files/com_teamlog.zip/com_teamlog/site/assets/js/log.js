var Teamlog = new Class({

	initialize: function(url, options){
		this.setOptions({
			msgDeletelog: 'Are you sure you want to delete the log?'
		}, options);

		this.url       = url;
		this.state     = $('state');
		this.projectId = $('project-id');
		this.logDelete = $$('#yoo-teamlog div.user-log ul.log span.delta a');
	},

	attachEvents: function() {
		new Tips($$('ul.log a.tooltip'));

		// logs
		new Observer(this.state, this.updateState.bind(this), { delay: 1000 });
		this.projectId.addEvent('change', this.getTasks.bind(this));
		this.logDelete.addEvent('click', this.confirmDelete.bind(this));
		if ($('team-log')) this.getTeamLog.bind(this).periodical(350000);

		// todos
		var wrp  = $('yoo-teamlog').getElement('div.todos');
		var trg  = $('todos-trigger');
		var todo = new Fx.Slide(wrp, { duration: 200 }).hide();
		trg.addEvent('click', function() { todo.toggle(); });
		this.attachTodos();
		this.getTodos.bind(this).periodical(300000);
	},

	updateState: function() {
		var obj = this;
		var fx  = this.state.effects({duration: 100, transition: Fx.Transitions.linear});

		new Ajax(this.url+'&task=updatestate', {
			method: 'post',
			data: 'description=' + obj.state.getValue(),
			onRequest: function(){
				obj.state.addClass('loading');
			},
			onComplete: function(){
				obj.state.removeClass('loading');
				fx.start({
					'background-color': '#ffffaa'
				}).chain(function(){
					this.setOptions({duration: 700});
					this.start({
						'background-color': '#ffffff'
					});
				});
			}
		}).request();
	},

	getTasks: function() {
		var id = this.projectId.getProperty('value');
		
		new Ajax(this.url+'&task=loadtasks', {
			method: 'post',
			data: 'project_id=' + id,
			update: $('task-id')
		}).request();

		new Ajax(this.url+'&task=loaddescription', {
			method: 'post',
			data: 'project_id=' + id,
			update: $('project-description')
		}).request();
	},

	confirmDelete: function(e) {
		var event = new Event(e);
		if (!confirm(this.options.msgDeletelog)) event.stop();
	},

	getTeamLog: function() {
		var obj = this;
		var bg  = $('yoo-teamlog').getElement('div.team-log-loading');

		new Ajax(this.url+'&task=loadteamlog', {
			method: 'get',
			update: $('team-log'),
			onRequest: function(){
				bg.addClass('loading');
			},
			onComplete: function(){
				bg.removeClass('loading');
				new Tips($$('div.team-log ul.log a.tooltip'));
			}
		}).request();
	},

	attachTodos: function() {
		var obj = this;
		
		$$('#todos-form ul li').addEvent('click', function(){
				var input = this.getElement('input');
				input.setProperty('value', (input.getProperty('value') == 1 ? 0 : 1));
				this.toggleClass('checked');
				obj.updateTodos();
			});
	},

	getTodos: function() {
		var obj = this;
		var bg  = $('yoo-teamlog').getElement('div.todos-bg');

		new Ajax(this.url+'&task=loadtodos', {
			method: 'get',
			update: $('todos'),
			onRequest: function(){
				bg.addClass('loading');
			},
			onComplete: function(){
				bg.removeClass('loading');
				obj.attachTodos();
			}
		}).request();
	},

	updateTodos: function() {
		var obj = this;
		var bg  = $('yoo-teamlog').getElement('div.todos-bg');
		var fx  = bg.effects({duration: 100, transition: Fx.Transitions.linear});
		
		$clear(this.timeout);
		this.timeout = function() {
			$('todos-form').send({
				onRequest: function(){
					bg.addClass('loading');
				},
				onComplete: function(){
					bg.removeClass('loading');
					fx.start({
						'background-color': '#FFE678'
					}).chain(function(){
						this.setOptions({duration: 700});
						this.start({
							'background-color': '#ffffaa'
						});
					});
				}
			});		
		}.delay(1000);
	}

});

Teamlog.implement(new Options);

var Observer = new Class({

	options: {
		'periodical': false,
		'delay': 1000
	},

	initialize: function(el, onFired, options){
		this.setOptions(options);
		this.addEvent('onFired', onFired);
		this.element = $(el);
		this.listener = this.fired.bind(this);
		this.value = this.element.getValue();
		if (this.options.periodical) this.timer = this.listener.periodical(this.options.periodical);
		else this.element.addEvent('keyup', this.listener);
	},

	fired: function() {
		var value = this.element.getValue();
		if (this.value == value) return;
		this.clear();
		this.value = value;
		this.timeout = this.fireEvent.delay(this.options.delay, this, ['onFired', [value]]);
	},

	clear: function() {
		$clear(this.timeout);
		return this;
	}
});

Observer.implement(new Options);
Observer.implement(new Events);