<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
   Class: TableTodo
   The Table Class for Todo. Manages the database operations.
*/
class TableTodo extends JTable {

	// int primary key
	var $id					= null;
	// int
	var $user_id			= null;
	// string
	var $description		= null;
	// datetime
	var $created			= null;
	// datetime
	var $modified			= null;
	// int
	var $state				= null;

	function __construct(&$db) {
		parent::__construct('#__teamlog_todo', 'id', $db);
	}

	function loadObjects($result) {
		$objects = array();
		if ($result != "") {
			foreach ($result as $row) {
				$object =& new Todo();
				$object->bind($row);
				$objects[] = $object;
			}
		}

		return $objects;
	}

	function getUserTodos($user_id) {
		$query = " SELECT * "
			. " FROM ".$this->_tbl
			. " WHERE user_id=".$user_id
			. " AND (state=".TODO_STATE_OPEN." OR state=".TODO_STATE_DONE.")" 
			. " ORDER BY created DESC";
		$this->_db->setQuery($query);

		$result = $this->_db->loadAssocList();
		$return = $this->loadObjects($result);
		return $return;
	}

}