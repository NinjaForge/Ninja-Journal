<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

// include table
require_once(dirname(dirname(__FILE__)).DS.'tables'.DS.'task.php');

define('TODO_STATE_OPEN', 0);
define('TODO_STATE_DONE', 1);
define('TODO_STATE_CLOSED', 2);

/*
   Class: Todo
   Todo related attributes and functions.
*/
class Todo extends YObject {

    /*
       Variable: id
         Primary key.
    */
	var $id	= null;

    /*
       Variable: user id
         User id.
    */
	var $user_id	= null;

    /*
       Variable: description
         Task description.
    */
	var $description = null;

    /*
       Variable: duration
         Todo state.
    */
	var $state = null;

    /*
       Variable: created
         Todos creation date.
    */
	var $created = null;

    /*
       Variable: modified
         Todos last modification date.
    */
	var $modified = null;

	/*
    	Function: __construct
    	  Constructor.

		Parameters:
	      id - Todo id.
 	*/
	function __construct($id = 0) {
		// load task if it exists
		if (!empty($id)) {
			$table =& JTable::getInstance('todo', 'Table');
			if ($table->load($id)) {
				$this->bind($table);
			}
		}
	}

	/*
    	Function: setstate
    	  Set todo state.

	   Returns:
	      Void.
 	*/
	function setState($val){
		$this->state = $val;
	}

	/*
    	Function: save
    	  Save todo to database.

	   Returns:
	      Boolean.
 	*/
	function save() {
		// load table object
		$table =& JTable::getInstance('todo', 'Table');
		$table->bind($this->getProperties());

		// check object
		if (!$table->check()) {
			$this->setError($table->getError());
			return false;
		}

		// store object
		if (!$result = $table->store()) {
			$this->setError($table->getError());
		}

		// set id
		if (empty($this->id)) {
			$this->id = $table->get('id');
		}

		return $result;
	}
	
	/*
    	Function: getstates
    	  Get todo states as array.

	   Returns:
	      Array.
 	*/	
	function getStates() {
		$states = array(
			TODO_STATE_OPEN => JText::_('Open'),
			TODO_STATE_DONE => JText::_('Done'),
			TODO_STATE_CLOSED => JText::_('Closed'));
			
		return $states;
	}

}