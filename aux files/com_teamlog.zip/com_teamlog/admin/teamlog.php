<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// set defines
define('TEAMLOG_ICON', 'teamlog.png');
define('TEAMLOG_TOOLBAR_TITLE', 'Teamlog - ');

// add jhtml path, css, js
JHTML::addIncludePath(dirname(__FILE__).'/helpers');
JHTML::script('default.js', 'administrator/components/com_teamlog/assets/js/');
JHTML::stylesheet('default.css', 'administrator/components/com_teamlog/assets/css/');

// get request vars
$controller = JRequest::getWord('controller');
$task       = JRequest::getCmd('task');

// validate controller
$controllers = array('type', 'project', 'task', 'log', 'report', 'todo');
if (!in_array($controller, $controllers)) $controller = 'report';

// add submenus
JSubMenuHelper::addEntry(JText::_('Reports'), 'index.php?option=com_teamlog&controller=report', $controller == 'report');
JSubMenuHelper::addEntry(JText::_('Todos'), 'index.php?option=com_teamlog&controller=todo', $controller == 'todo');
JSubMenuHelper::addEntry(JText::_('Logs'), 'index.php?option=com_teamlog&controller=log', $controller == 'log');
JSubMenuHelper::addEntry(JText::_('Projects'), 'index.php?option=com_teamlog&controller=project', $controller == 'project');
JSubMenuHelper::addEntry(JText::_('Tasks'), 'index.php?option=com_teamlog&controller=task', $controller == 'task');
JSubMenuHelper::addEntry(JText::_('Types'), 'index.php?option=com_teamlog&controller=type', $controller == 'type');

// set the table directory
JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

// load controller
require_once(JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');

// load classes & helper
require_once(JPATH_COMPONENT.DS.'classes'.DS.'factory.php');
require_once(JPATH_COMPONENT.DS.'helpers'.DS.'date.php');
foreach($controllers as $con){
	$helper_path = JPATH_COMPONENT.DS.'helpers'.DS.$con.'.php';
	if (file_exists($helper_path)) {
		require_once($helper_path);
	}
}

$classname  = $controller.'Controller';
$controller = new $classname();

// perform the request task
$controller->execute($task);
$controller->redirect();