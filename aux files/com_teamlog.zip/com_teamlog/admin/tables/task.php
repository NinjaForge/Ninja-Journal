<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
   Class: TableTask
   The Table Class for Task. Manages the database operations.
*/
class TableTask extends JTable {

	/** @var int primary key */
	var $id					= null;
	/** @var int project id */
	var $project_id			= null;
	/** @var int */
	var $name				= null;
	/** @var string */
	var $description		= null;
	/** @var int */
	var $state				= null;
	/** @var int type id */
	var $type_id			= null;

	/**
	 * @param database A database connector object
	 */
	function __construct(&$db) {
		parent::__construct('#__teamlog_task', 'id', $db);
	}

	function setTaskState($id, $state) {
		$query = " UPDATE " . $this->_tbl
		. " SET state=" . $state
		. " WHERE id=" . $id;
		$this->_db->setQuery($query);
		if (!$this->_db->query()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		return true;
	}

	function loadObjects($result) {
		$objects = array();
		if ($result != "") {
			foreach ($result as $row) {
				$object =& new Task();
				$object->bind($row);
				$objects[] = $object;
			}
		}

		return $objects;
	}

	function getTasks($project_id) {
		$query = " SELECT * "
			. " FROM ".$this->_tbl
			. " WHERE project_id=".$project_id
			. " OR project_id=0"
			. " AND state=".TASK_STATE_OPEN
			;
		$this->_db->setQuery($query);

		$result = $this->_db->loadAssocList();
		$return = $this->loadObjects($result);
		return $return;
	}

}