<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/*
   Class: ReportViewReport
   The View Class for Report
*/
class ReportViewReport extends JView {

	function display($tpl = null) {
		global $mainframe;

		$db       =& JFactory::getDBO();
		$user     =& JFactory::getUser();
		$config   =& JFactory::getConfig();
		$model    =& $this->getModel();

		// set toolbar items
		JToolBarHelper::title(TEAMLOG_TOOLBAR_TITLE.JText::_('Reports'), TEAMLOG_ICON);

		// get request vars
		$option       = JRequest::getCmd('option');
		$controller   = JRequest::getWord('controller');
		$task 		  = JRequest::getVar('task', '');
		$from_period  = JRequest::getVar('from_period', '?');
		$until_period = JRequest::getVar('until_period', '?');
		$user_id   	  = JRequest::getVar('user_id', 0);
		$project_id   = JRequest::getVar('project_id', 0);

		// set date presets
		$date   = JFactory::getDate();
		$date   = $date->toUnix();
		$date   = mktime(0, 0, 0, date('n', $date), date('j', $date), date('Y', $date));
		$monday = (date('w', $date) == 1) ? $date : strtotime('last Monday', $date);
		$date_presets['last30'] = array(
			'name'  => 'Last 30 days',
			'from'  => date('Y-m-d', strtotime('-29 day', $date)),
			'until' => date('Y-m-d', $date));
		$date_presets['today'] = array(
			'name'  => 'Today',
			'from'  => date('Y-m-d', $date),
			'until' => date('Y-m-d', $date));
		$date_presets['week'] = array(
			'name'  => 'This Week',
			'from'  => date('Y-m-d', $monday),
			'until' => date('Y-m-d', strtotime('+6 day', $monday)));
		$date_presets['month'] = array(
			'name'  => 'This Month',
			'from'  => date('Y-m-d', mktime(0, 0, 0, date('n', $date), 1, date('Y', $date))),
			'until' => date('Y-m-d', mktime(0, 0, 0, date('n', $date)+1, 0, date('Y', $date))));
		$date_presets['year'] = array(
			'name'  => 'This Year',
			'from'  => date('Y-m-d', mktime(0, 0, 0, 1, 1, date('Y', $date))),
			'until' => date('Y-m-d', mktime(0, 0, 0, 12, 31, date('Y', $date))));

		// set period
		$tzoffset     = $config->getValue('config.offset');
		$from         = JFactory::getDate($from_period, $tzoffset);
		$until        = JFactory::getDate($until_period, $tzoffset);
		
		// check period - set to defaults if no value is set or dates cannot be parsed
		if ($from->_date === false || $until->_date === false) {
			if ($from_period != '?' && $until_period != '?') {
				JError::raiseNotice(500, JText::_('Please enter a valid date format (YYYY-MM-DD)'));
			}
			$from_period  = $date_presets['last30']['from'];
			$until_period = $date_presets['last30']['until'];
			$from         = JFactory::getDate($from_period, $tzoffset);
			$until        = JFactory::getDate($until_period, $tzoffset);
		} else {
			if ($from->toUnix() > $until->toUnix()){
				list($from_period, $until_period) = array($until_period, $from_period);
				list($from, $until) = array($until, $from);
			}
		}		
				
		// simpledate select
		$select  = '';
		$options = array(JHTML::_('select.option', '', '- '.JText::_('Select Period').' -', 'text', 'value'));
		foreach ($date_presets as $name => $value) {
			$options[] = JHTML::_('select.option', $name, JText::_($value['name']), 'text', 'value');
			if ($value['from'] == $from_period && $value['until'] == $until_period) {
				$select = $name;
			}
		}
		$lists['select_date'] = JHTML::_('select.genericlist', $options, 'period', 'class="inputbox" size="1"', 'text', 'value', $select);

		// user select
		$query = 'SELECT b.id AS value, b.name AS text'
			. ' FROM #__teamlog_log AS a '
			. ' LEFT JOIN #__users AS b ON a.user_id = b.id'		
			. ' GROUP BY b.id'
			. ' ORDER BY b.name';
		$options = JHTML::_('select.option', '', '- '.JText::_('Select User').' -');		
		$lists['select_user'] = JHTML::_('teamlog.querylist', $query, $options, 'user_id', 'class="inputbox auto-submit"', 'value', 'text', $user_id);

		// project select
		$query = 'SELECT b.id AS value, b.name AS text'
			. ' FROM #__teamlog_log AS a '
			. ' LEFT JOIN #__teamlog_project AS b ON a.project_id = b.id'		
			. ' GROUP BY b.id'
			. ' ORDER BY b.name';
		$options = JHTML::_('select.option', '', '- '.JText::_('All Projects').' -');
		$lists['select_project'] = JHTML::_('teamlog.querylist', $query, $options, 'project_id', 'class="inputbox auto-submit" size="1"', 'value', 'text', $project_id);

		// load chart library
		include(dirname(dirname(dirname(__FILE__))).'/libraries/fusioncharts/class/FusionCharts_Gen.php');
		$swfpath = JURI::base().'components/com_teamlog/libraries/fusioncharts/charts/';
		$params  = array(
			'numberPrefix=', 'decimalPrecision=0',
			'formatNumberScale=1', 'showNames=1',
			'showValues=0', 'pieBorderAlpha=100',
			'shadowXShift=4', 'shadowYShift=4',
			'shadowAlpha=60', 'pieBorderColor=f1f1f1');

		// set the view
		if ($project_id) {
			// create report
			$report        = $model->getProjectReport($project_id, $user_id, $from_period, $until_period);
			$contentLayout = 'report_project';

			// create chart
			$chart_t = new FusionCharts('Pie2D','400','300');
			$chart_t->setSWFPath($swfpath);
			$chart_t->setChartParams(implode(';', array_merge($params, array('caption=Type stats','xAxisName=Types',	'yAxisName=Minutes'))));
			$colors = $this->getColorscheme('#224565', count($report['type']));
			foreach ($report['type'] as $type) {
				$param  = ($type['total'] / $report['total'] >= 0.05) ? 'name='.$type['name'] : 'name=';
				$param .= ';hoverText='.$type['name'].' ('.DateHelper::formatTimespan($type['total'], 'hr mi').')'.';color='.array_shift($colors);
				$chart_t->addChartData($type['total'], $param);	
			}

			$chart_u = new FusionCharts('Pie2D','400','300');
			$chart_u->setSWFPath($swfpath);
			$chart_u->setChartParams(implode(';', array_merge($params, array('caption=User stats','xAxisName=Users',	'yAxisName=Minutes'))));
			$colors = $this->getColorscheme('#21561f', count($report['user']));
			foreach ($report['user'] as $usr) {
				$param  = ($usr['total'] / $report['total'] >= 0.05) ? 'name='.$usr['name'] : 'name=';
				$param .= ';hoverText='.$usr['name'].' ('.DateHelper::formatTimespan($usr['total'], 'hr mi').')'.';color='.array_shift($colors);
				$chart_u->addChartData($usr['total'], $param);	
			}

			// set template vars
			$this->assignRef('type_chart', $chart_t);
			$this->assignRef('user_chart', $chart_u);

		} elseif ($user_id) {
			// create report
			$report        = $model->getUserReport($user_id, $from_period, $until_period);
			$contentLayout = 'report_user';

			// create chart
			$chart = new FusionCharts('Pie2D','700','300');
			$chart->setSWFPath($swfpath);
			$chart->setChartParams(implode(';', array_merge($params, array('caption=Project stats','xAxisName=Types',	'yAxisName=Minutes'))));
			$colors = $this->getColorscheme('#FC7000', count($report['project']));
			foreach ($report['project'] as $project) {
				$param  = ($project['total'] / $report['total'] >= 0.05) ? 'name='.$project['name'] : 'name=';
				$param .= ';hoverText='.$project['name'].' ('.DateHelper::formatTimespan($project['total'], 'hr mi').')'.';color='.array_shift($colors);
				$chart->addChartData($project['total'], $param);	
			}

			// set template vars
			$this->assignRef('proj_chart', $chart);

		} else {
			// create report
			$report		   = $model->getPeriodReport($from_period, $until_period);
			$contentLayout = 'report_period';

			// create chart
			$chart = new FusionCharts('Pie2D','700','300');
			$chart->setSWFPath($swfpath);
			$chart->setChartParams(implode(';', array_merge($params, array('caption=Project stats','xAxisName=Types',	'yAxisName=Minutes'))));
			$colors = $this->getColorscheme('#6B007F', count($report['data']));
			foreach ($report['data'] as $project) {
				$param  = ($project['duration'] / $report['total'] >= 0.05) ? 'name='.$project['name'] : 'name=';
				$param .= ';hoverText='.$project['name'].' ('.DateHelper::formatTimespan($project['duration'], 'hr mi').')'.';color='.array_shift($colors);
				$chart->addChartData($project['duration'], $param);	
			}

			// set template vars
			$this->assignRef('proj_chart', $chart);
				
		}

		// set template vars
		$this->assignRef('user', $user);
		$this->assignRef('option', $option);
		$this->assignRef('controller', $controller);
		$this->assignRef('lists', $lists);
		$this->assignRef('project_id', $project_id);
		$this->assignRef('user_id', $user_id);
		$this->assignRef('from_period', $from_period);
		$this->assignRef('until_period', $until_period);
		$this->assignRef('report', $report);
		$this->assignRef('contentLayout', $contentLayout);
		$this->assignRef('date_presets', $date_presets);

		parent::display($tpl);
	}

	function getColorscheme($color, $count) {
		preg_match("/^([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i", preg_replace("/^#/", "", $color), $matches);
		$color_hex = array(strtolower($color));
		$color_rgb = array_slice($matches, 1);

		for ($i=0; $i < 3; $i++) {
			$color_rgb[$i] = hexdec($color_rgb[$i]);
		}
		
		for ($i=1; $i < $count; $i++) {
			$color_hex[$i] = "#";
			for ($j=0; $j < 3; $j++) { 
				$color_rgb[$j] += 15;
				if ($color_rgb[$j] < 0)   $color_rgb[$j] = 0;
				if ($color_rgb[$j] > 255) $color_rgb[$j] = 255;
				$value_hex      = dechex($color_rgb[$j]);
				$color_hex[$i] .= strlen($value_hex) < 2 ? "0".$value_hex : $value_hex;
			}
		}

		return $color_hex;
	}

}