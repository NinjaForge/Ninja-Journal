DROP TABLE `#__teamlog_log`;
DROP TABLE `#__teamlog_project`;
DROP TABLE `#__teamlog_task`;
DROP TABLE `#__teamlog_type`;
DROP TABLE `#__teamlog_todo`;
DROP TABLE `#__teamlog_userdata`;