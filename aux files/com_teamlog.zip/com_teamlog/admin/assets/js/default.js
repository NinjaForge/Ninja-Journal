window.addEvent('domready', function(){
	$$('select.auto-submit').addEvent('change', function(){
		document.adminForm.submit();
	});
});